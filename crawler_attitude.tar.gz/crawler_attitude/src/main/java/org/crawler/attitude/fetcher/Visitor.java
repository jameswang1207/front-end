package org.crawler.attitude.fetcher;

import org.crawler.attitude.model.CrawlStructures;
import org.crawler.attitude.model.Page;

public interface Visitor {
	
	public void visitor(Page page, CrawlStructures next) throws Exception;
}
