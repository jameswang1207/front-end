package org.crawler.attitude.plugin.mongo;

import org.crawler.attitude.crawldb.Generator;
import org.crawler.attitude.model.CrawlStructure;

public class MongoGenerator implements Generator{

	@Override
	public void setMaxExecuteCount(int maxExecuteCount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getTotalGenerate() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public CrawlStructure next() {
		// TODO Auto-generated method stub
		return null;
	}

}
