package org.crawler.attitude.plugin.mongo;

public class MongoCrawler {

}
