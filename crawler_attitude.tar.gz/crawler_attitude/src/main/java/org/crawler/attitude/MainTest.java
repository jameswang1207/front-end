package org.crawler.attitude;

import org.crawler.attitude.http.HttpRequest;
public class MainTest {
    public static void main(String args[]){
    	try {
    		String url = "https://guang.taobao.com/ifashion/kantugouDetail.htm?spm=a21ct.88421.403491.13.TbvH0X&contentId=331153&gender=1";
			HttpRequest httpRequest = new HttpRequest(url);
			httpRequest.getResponse().toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
}
