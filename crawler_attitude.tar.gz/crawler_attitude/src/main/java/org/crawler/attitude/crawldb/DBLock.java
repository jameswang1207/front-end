package org.crawler.attitude.crawldb;

public interface DBLock {
    public void lock() throws Exception;
    
    public boolean isLock() throws Exception;
    
    public void unLock() throws Exception;
}
