package org.crawler.attitude.util;
/**
 * 爬虫的全局配置
 * @author JamesWang
 */
public class Config {
	/* 默认的user_agent*/
    public static String DEFAULT_USER_AGENT="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36";
    /*默认接受来自文件的大小*/
    public static int MAX_RECEIVE_SIZE = 1000 * 1000;
    //??
    public static long THREAD_KILLER = 1000*60*2;
    /*等待线程结束的时间*/
    public static long WAIT_THREAD_END_TIME = 1000*60;
    /*最大连续重定向次数*/
    public static int MAX_REDIRECT = 2;
    /*设置连接主机超时（单位：毫秒）*/
    public static int TIMEOUT_CONNECT = 3000;
    /*设置从主机读取数据超时（单位：毫秒）*/
    public static int TIMEOUT_READ = 10000;
    /*默认的执行时间*/
    public static int MAX_EXECUTE_COUNT=10;
    /*默认的请求方式*/
    public static String DEFAULT_HTTP_METHOD="GET";
}
