package org.crawler.attitude.crawl;

public class AutoParseCrawler {

}
