package org.crawler.attitude.crawldb;

import org.crawler.attitude.model.CrawlStructure;

public interface Injector {
    public void injector(CrawlStructure crawStructure) throws Exception;
}
