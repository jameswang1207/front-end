package org.crawler.attitude.fetcher;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.crawler.attitude.crawldb.DBManager;
import org.crawler.attitude.crawldb.Generator;
import org.crawler.attitude.model.CrawlStructure;
import org.crawler.attitude.model.CrawlStructures;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this is fetcher: 抓取器
 * 
 * @author james
 *
 */
public class Fetcher {
	public static final Logger LOG = LoggerFactory.getLogger(Fetcher.class);

	// 引入dbmanager
	DBManager dbmanager;

	// 引入执行器
	Executor executor;

	// 当前线程是否在运行
	volatile boolean running;
	// 定义变量,记录线程的数量
	private AtomicInteger activeThread;
	private AtomicInteger startThread;
	private AtomicLong lastRequestStart;
	private FetchQueue fetchQueue;

	public static final int FETCHER_SUCCESS = 1;
	public static final int FETCHER_FAIL = 2;

	private int threads = 50;
	private long executeInterval = 0;

	public Executor getExecutor() {
		return executor;
	}

	public void setExecutor(Executor executor) {
		this.executor = executor;
	}

	// 需要抓取的数据
	public static class FetchItem {
		public CrawlStructure datum;

		public FetchItem(CrawlStructure datum) {
			this.datum = datum;
		}
	}

	public static class FetchQueue {
		AtomicInteger totalSize = new AtomicInteger(0);
		// 对于随机访问get和set，ArrayList优于LinkedList，因为ArrayList可以随机定位，而LinkedList要移动指针一步一步的移动到节点处。（参考数组与链表来思考）
		// 对于新增和删除操作add和remove，LinedList比较占优势，只需要对指针进行修改即可，而ArrayList要移动数据来填补被删除的对象的空间
		private final List<FetchItem> queue = Collections.synchronizedList(new LinkedList<FetchItem>());

		public void clear() {
			this.queue.clear();
		}

		public int getSize() {
			return this.queue.size();
		}

		public synchronized void addFetcherItem(FetchItem item) {
			this.queue.add(item);
			this.totalSize.incrementAndGet();
		}

		public synchronized FetchItem getFetcherItem() {
			if (this.queue.isEmpty()) {
				return null;
			}
			return this.queue.remove(0);
		}

		public synchronized void dump() {
			for (int i = 0; i < this.getSize(); i++) {
				FetchItem item = this.queue.get(i);
				LOG.info("  " + i + ". " + item.datum.getUrl());
			}
		}
	}

	// 将要抓取的任务添加到fetchQueue中
	public class FetcherProducer extends Thread {
		public FetchQueue queue;

		public Generator generator;

		public int size;

		public void stopProducer() {
			running = false;
			try {
				while (this.isAlive()) {
					Thread.sleep(1000);
					LOG.info("stopping producer......");
				}
			} catch (Exception ex) {
				LOG.info("stopping producer has exception");
			}
		}

		@Override
		public void run() {
			boolean hasMore = true;
			running = true;
			while (hasMore && running) {
				int feed = size - queue.getSize();
				if (feed <= 0) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						LOG.info("Have not data can fetcher");
					}
					continue;
				}

				while (feed > 0 && hasMore && running) {
					CrawlStructure datum = generator.next();
					hasMore = datum == null ? false : true;

					if (hasMore) {
						queue.addFetcherItem(new FetchItem(datum));
						feed--;
					}

				}
			}
		}
	}

	// 从fetchQueue 中获取item来进行数据的拉取
	public class FetcherThread extends Thread {
		@Override
		public void run() {
			try {
				activeThread.incrementAndGet();
				startThread.incrementAndGet();
				FetchItem item = null;

				if (running) {
					try {
						item = fetchQueue.getFetcherItem();
						if (item != null) {

							CrawlStructure crawlStructure = item.datum;
							CrawlStructures next = new CrawlStructures();

							try {
								executor.execute(crawlStructure, next);
								LOG.info("success:" + crawlStructure.getKey());
								crawlStructure.setStatus(CrawlStructure.STATUS_DB_SUCCESS);
							} catch (Exception e) {
								LOG.info("fail:" + crawlStructure.getKey());
								crawlStructure.setStatus(CrawlStructure.STATUS_DB_FAILED);
							}
							crawlStructure.increaseExecuteCount(1);
							crawlStructure.setExecuteTime(System.currentTimeMillis());

							// 数据存入数据库
							try {
								dbmanager.wrtieFetch(crawlStructure);
								if (crawlStructure.getStatus() == CrawlStructure.STATUS_DB_SUCCESS && !next.isEmpty()) {
									// 若问价写入成功，将全部的文件进行写入
									dbmanager.writeParse(next);
								}
							} catch (Exception exception) {
								LOG.info("DB update or insert has exceptions");
							}

							if (executeInterval > 0) {
								try {
									Thread.sleep(executeInterval);
								} catch (InterruptedException e) {
									LOG.info("Thread sleep is InterruptedException");
								}
							}
						}
					} catch (Exception ex) {
						LOG.info("Thread have exception");
					}
				}
			} catch (Exception ex) {
				LOG.info("Thread hava exception");
			} finally {
				// 较少当活着的线程
				activeThread.decrementAndGet();
			}
		}

		/**
		 * 抓取当前所有任务，会阻塞到爬取完成
		 *
		 * @param generator
		 *            给抓取提供任务的Generator(抓取任务生成器)
		 * @throws IOException
		 *             异常
		 */
		public void fetchAll(Generator generator) throws Exception {

		}
	}

	public void stop() {
		this.running = false;
	}

	/**
	 * 返回爬虫的线程数
	 *
	 * @return 爬虫的线程数
	 */
	public int getThreads() {
		return threads;
	}

	/**
	 * 设置爬虫的线程数
	 *
	 * @param threads
	 *            爬虫的线程数
	 */
	public void setThreads(int threads) {
		this.threads = threads;
	}

	public DBManager getDBManager() {
		return dbmanager;
	}

	public void setDBManager(DBManager dbmanager) {
		this.dbmanager = dbmanager;
	}

	public long getExecuteInterval() {
		return executeInterval;
	}

	public void setExecuteInterval(long executeInterval) {
		this.executeInterval = executeInterval;
	}
}
