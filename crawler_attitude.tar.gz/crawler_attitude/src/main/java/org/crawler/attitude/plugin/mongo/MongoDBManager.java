package org.crawler.attitude.plugin.mongo;

import java.util.Iterator;

import org.bson.Document;
import org.crawler.attitude.crawldb.DBManager;
import org.crawler.attitude.model.CrawlStructure;
import org.crawler.attitude.model.CrawlStructures;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDBManager extends DBManager {

	Logger log = LoggerFactory.getLogger(MongoDBManager.class);

	// this is database name
	String crawlID = "crawlerMongo";
	// 连接到 mongodb 服务
	MongoClient client;
	// 连接到数据库
	MongoDatabase dataBase;

	MongoGenerator mongoGenerator;

	public MongoDBManager(MongoClient client, MongoDatabase dataBase) {
		this.client = client;
		this.dataBase = dataBase;
	}

	@Override
	public boolean isDBExists() {
		Iterator<String> names = client.listDatabaseNames().iterator();
		while (names.hasNext()) {
			if (names.next().equals(this.crawlID)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void injector(CrawlStructure crawStructure) throws Exception {
		super.injector(crawStructure);
	}

	@Override
	public void lock() throws Exception {
		MongoCollection<Document> lock = dataBase.getCollection("lock");
        Document lockDoc = new Document("_id", "lock")
                .append("lock", "locked");
        lock.insertOne(lockDoc);
	}

	@Override
	public boolean isLock() throws Exception {
		MongoCollection<Document> lock = dataBase.getCollection("lock");
        Document idDoc = new Document("_id", "lock");
        Document doc = lock.find(idDoc).first();
        if (doc != null && doc.getString("lock").equals("locked")) {
        	return true;
        } else {
        	return false;
        }
	}

	@Override
	public void unLock() throws Exception {
        MongoCollection<Document> lock = dataBase.getCollection("lock");
        Document lockDoc = new Document("_id", "lock").append("lock", "unlocked");
        MongoDBUtils.updateOrInsert(lock, lockDoc);
	}

    MongoCollection<?> fetch = null;
    MongoCollection<?> link = null;
    MongoCollection<?> redirect = null;
    
	@Override
	public void initWriter() throws Exception {
        fetch = dataBase.getCollection("fetch");
        link = dataBase.getCollection("link");
        redirect = dataBase.getCollection("redirect");
	}

	@Override
	public void wrtieFetch(CrawlStructure fetchStructure) throws Exception {
		// TODO Auto-generated method stub
		super.wrtieFetch(fetchStructure);
	}

	@Override
	public void writeRedirect(CrawlStructure redirectStructure, String realUrl) throws Exception {
		// TODO Auto-generated method stub
		super.writeRedirect(redirectStructure, realUrl);
	}

	@Override
	public void closeWriter() throws Exception {
		// TODO Auto-generated method stub
		super.closeWriter();
	}

	public void open() {
		dataBase = client.getDatabase(crawlID);
	}

	public void close() {
        client.close();
	}

	public void clear() {
		dataBase = client.getDatabase(this.crawlID);
		dataBase.drop();
	}

	@Override
	public void merge() throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void writeParse(CrawlStructures next) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
