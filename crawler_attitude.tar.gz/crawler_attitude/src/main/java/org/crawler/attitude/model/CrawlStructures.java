package org.crawler.attitude.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 用于存储多个CrawlStructure的数据结构
 * 
 * @author JamesWang
 */

public class CrawlStructures implements Iterable<CrawlStructure>{
	List<CrawlStructure> crawStructures = new ArrayList<CrawlStructure>();

	public CrawlStructures() {

	}

	public CrawlStructures add(CrawlStructure crawlStructure) {
		this.crawStructures.add(crawlStructure);
		return this;
	}

	public CrawlStructures remove(CrawlStructure crawlStructure) {
		this.crawStructures.remove(crawlStructure);
		return this;
	}

	public CrawlStructures remove(int index){
		this.crawStructures.remove(index);
		return this;
	}
	
	@Override
	public Iterator<CrawlStructure> iterator() {
		return this.crawStructures.iterator();
	}
	
	public CrawlStructure get(int index){
		return  this.crawStructures.get(index);
	}
	
	public int size(){
		return this.crawStructures.size();
	}
	
	public void clear(){
		this.crawStructures.clear();
	}
	
	public boolean isEmpty(){
		return this.crawStructures.isEmpty();
	}

	@Override
	public String toString() {
		return this.crawStructures.toString();
	}
	
	
}
