package org.crawler.attitude.model;

/**
 * 保存网页中的源码信息
 * @author JamesWang
 */
public class Page {

}
