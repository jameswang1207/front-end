package org.crawler.attitude.http;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.crawler.attitude.model.CrawlStructure;
import org.crawler.attitude.util.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 代理服务器的功能就是代理网络用户去取得网络信息。我们使用网络浏览器直接连接其他Internet站点取得网络信息时，
 * 通常需要发送Request请求来等到响应。代理服务器是介于浏览器和Web服务器之间的一台服务器，
 * 有了它之后，浏览器不是直接到Web服务器去取得网页数据而是向代理服务器发出请求，
 * Request请求会先送到代理服务器，由代理服务器来取回浏览器所需要的信息并送回给网络浏览器。
 * 而且，大部分代理服务器都具有缓冲的功能，就好像一个大的Cache，它有很大的存储空间，它不断将新取得的数据储存到它本机的存储器上，
 * 如果浏览器所请求的数据在它本机的存储器上已经存在而且是最新的，那么它就不重新从Web服务器取数据，而直接将存储器上的数据传送给用户的浏览器，
 * 这样就能显著提高浏览速度和效率。
 *
 * 归纳起来代理服务器主要提供如下两个功能： 突破自身IP限制，对外隐藏自身IP地址。突破IP限制包括访问国外受限站点，访问国内特定单位、团体的内部资源。
 * 提高访问速度，代理服务器提供的缓冲功能可以避免每个用户都直接访问远程主机，从而提高客户端访问速度。
 * 
 * @author JamesWang
 */
public class HttpRequest {
	private static final Logger log = LoggerFactory.getLogger(HttpRequest.class);

	protected Proxy proxy = null;
	protected int MAX_REDIRECT = Config.MAX_REDIRECT;
	protected Map<String, List<String>> headerMap = null;
	protected String method = Config.DEFAULT_HTTP_METHOD;
	protected CrawlStructure crawlStructure = null;
	protected boolean doinput = true;
	protected boolean dooutput = true;
	protected boolean followRedirects = false;
	protected int timeoutForConnect = Config.TIMEOUT_CONNECT;
	protected int timeoutForRead = Config.TIMEOUT_READ;
	protected byte[] outputData = null;

	public HttpRequest(String url) throws Exception {
		this.crawlStructure = new CrawlStructure(url);
		setUserAgent(Config.DEFAULT_USER_AGENT);
	}

	public HttpRequest(String url, Proxy proxy) throws Exception {
		this(url);
		this.proxy = proxy;
	}

	public HttpRequest(CrawlStructure crawlStructure) throws Exception {
		this.crawlStructure = crawlStructure;
		setUserAgent(Config.DEFAULT_USER_AGENT);
	}

	public HttpRequest(CrawlStructure crawlStructure, Proxy proxy) throws Exception {
		this(crawlStructure);
		this.proxy = proxy;
	}

	public HttpResponse getResponse() throws Exception {
		URL url = new URL(crawlStructure.getUrl());
		HttpResponse response = new HttpResponse(url);
		int code = -1;

		HttpURLConnection con = null;
		InputStream in = null;
		try {
			for (int redirect = 0; redirect <= MAX_REDIRECT; redirect++) {
				if (proxy == null) {
					con = (HttpURLConnection) url.openConnection();
				} else {
					con = (HttpURLConnection) url.openConnection(proxy);
				}

				config(con);

				// this is outPutStream
				if (outputData == null) {
					OutputStream os = con.getOutputStream();
				}

				code = con.getResponseCode();
				log.info("********this is response code************" + code);
				// 记录返回的code
				if (redirect == 0) {
					response.setCode(code);
				}

				if (code == HttpURLConnection.HTTP_NOT_FOUND) {
					response.setNotFound(true);
					return response;
				}
				boolean needBreak = false;
				switch (code) {
				case HttpURLConnection.HTTP_MOVED_PERM:
					log.info("*******302 重定向又称之为302代表暂时性转移Temporarily Moved***");
				case HttpURLConnection.HTTP_MOVED_TEMP:
					log.info("*******301 Moved Permanently***");
					response.setRedirect(true);
					if (redirect == MAX_REDIRECT) {
						throw new Exception("redirect to much");
					}
					String location = con.getHeaderField("Location");
					if (location == null) {
						throw new Exception("redirect with no location");
					}
					String originUrl = url.toString();
					URL realUrl = new URL(url, location);
					response.setRealUrl(realUrl);
					log.info("redirect from " + originUrl + " to " + realUrl.toString());
					continue;
				case HttpURLConnection.HTTP_USE_PROXY:
					log.info("******Use Proxy******");
					break;
				case HttpURLConnection.HTTP_UNAVAILABLE:
					log.info("******Service Unavailable***");
					break;
				case HttpURLConnection.HTTP_NOT_ACCEPTABLE:
					log.info("******Not Acceptable********");
					break;
				case HttpURLConnection.HTTP_NO_CONTENT:
					log.info("******No Content************");
					break;
				default:
					needBreak = true;
					break;
				}
				if (needBreak) {
					break;
				}
			}

			in = con.getInputStream();
			String contentEncoding = con.getContentEncoding();
			if (contentEncoding != null && contentEncoding.equals("gzip")) {
				in = new GZIPInputStream(in);
			}

			// 设置接受的最大字节数
			// 当你资源不足够用时,选择BufferedOutputStream是最佳的选择,
			// 当你选择快速完成一个作业时,可以选择ByteArrayOutputStream之类的输出流
			byte[] bytes = new byte[1024];
			int read;
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			while ((read = in.read(bytes)) != -1) {
				bos.write(bytes, 0, read);
			}
			//获取到网页信息
            //log.info("**********************"+bos.toString()+"*********************");
			// 设置返回的内容
			response.setContent(bos.toByteArray());
			response.setHeaders(con.getHeaderFields());
			bos.close();
			return response;
		} catch (Exception ex) {
			log.info("write data throws data", ex);
			throw ex;
		} finally {
			if (in != null) {
				in.close();
			}
		}
	}

	public void config(HttpURLConnection con) throws Exception {
		// 设定请求的方法为"POST"，默认是GET
		con.setRequestMethod(method);
		// 设置此 HttpURLConnection 实例是否应该自动执行http重定向
		con.setInstanceFollowRedirects(followRedirects);
		// 设置是否向HttpURLConnection输出，因为这个是post请求，参数要放在http正文内，因此需要设为true,
		// 默认情况下是false;
		con.setDoOutput(dooutput);
		// 设置是否从HttpURLConnection读入，默认情况下是true;
		con.setDoInput(doinput);
		// 设置连接主机超时（单位：毫秒）
		con.setConnectTimeout(timeoutForConnect);
		// 设置从主机读取数据超时（单位：毫秒）
		con.setReadTimeout(timeoutForRead);

		// 设置请求头
		if (headerMap != null) {
			for (Map.Entry<String, List<String>> entry : headerMap.entrySet()) {
				String key = entry.getKey();
				List<String> valueList = entry.getValue();
				for (String value : valueList) {
					con.addRequestProperty(key, value);
				}
			}
		}
	}

	public void setUserAgent(String userAgent) {
		setHeader("User-Agent", userAgent);
	}

	public void setCookie(String cookie) {
		setHeader("Cookie", cookie);
	}

	public void setHeader(String key, String value) {
		if (key == null) {
			throw new NullPointerException("Set header's key is null");
		}
		if (value == null) {
			throw new NullPointerException("Set header's value is null");
		}
		initHeaderMap();
		List<String> valueList = new ArrayList<String>();
		valueList.add(value);
		headerMap.put(key, valueList);
	}

	public void addHeader(String key, String value) {
		if (key == null) {
			throw new NullPointerException("add header key is null");
		}

		if (value == null) {
			throw new NullPointerException("add header key is null");
		}

		initHeaderMap();
		List<String> valueList = headerMap.get(key);
		if (valueList == null) {
			valueList = new ArrayList<String>();
			headerMap.put(key, valueList);
		}
		valueList.add(value);
	}

	public void removeHeader(String key) {
		if (key == null) {
			throw new NullPointerException("header's key is null");
		}

		if (headerMap != null) {
			headerMap.remove(key);
		}
	}

	private void initHeaderMap() {
		if (headerMap == null) {
			headerMap = new HashMap<String, List<String>>();
		}
	}

	/**
	 * Class variable get and set function
	 * 
	 * @return
	 */
	public Map<String, List<String>> getHeaderMap() {
		return headerMap;
	}

	public void setHeaderMap(Map<String, List<String>> headerMap) {
		this.headerMap = headerMap;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public CrawlStructure getCrawlStructure() {
		return crawlStructure;
	}

	public void setCrawlStructure(CrawlStructure crawlStructure) {
		this.crawlStructure = crawlStructure;
	}

	public int getMAX_REDIRECT() {
		return MAX_REDIRECT;
	}

	public void setMAX_REDIRECT(int mAX_REDIRECT) {
		MAX_REDIRECT = mAX_REDIRECT;
	}

}
