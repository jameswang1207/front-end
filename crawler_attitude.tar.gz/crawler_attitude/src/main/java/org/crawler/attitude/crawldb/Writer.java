package org.crawler.attitude.crawldb;

import org.crawler.attitude.model.CrawlStructure;
import org.crawler.attitude.model.CrawlStructures;

/**
 * 爬取过程中，写入爬取历史、网页Content、解析信息
 * @author james
 *
 */
public interface Writer {
	//初始化writer操作
    public void initWriter() throws Exception;
    
    //写入抓取的部分
    public void wrtieFetch(CrawlStructure fetchStructure) throws Exception;
    
    //写入跳转的部分
    public void writeRedirect(CrawlStructure redirectStructure, String realUrl) throws Exception;
    
    //将文本内容全部写入
    public void writeParse(CrawlStructures next) throws Exception;
    
    //关闭Writer流
    public void closeWriter() throws Exception;
}
