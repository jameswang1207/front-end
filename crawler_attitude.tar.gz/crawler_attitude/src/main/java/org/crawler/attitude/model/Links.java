package org.crawler.attitude.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Links implements Iterable<String> {

	List<String> links = new ArrayList<String>();

	public Links() {

	}

	public Links(String url) {
		add(url);
	}

	public Links(Collection<String> links) {
		add(links);
	}

	@Override
	public Iterator<String> iterator() {
		return links.iterator();
	}

	public Links add(String url) {
		this.links.add(url);
		return this;
	}

	public Links add(Collection<String> links) {
		this.links.addAll(links);
		return this;
	}

	// 从页面上获取相应的href
	public Links addBySelector(Document doc, String cssSelector) {
		Elements elements = doc.select(cssSelector);
		for (Element ele : elements) {
			if (ele.hasAttr("href")) {
				String href = ele.attr("abs:href");
				this.add(href);
			}
		}
		return this;
	}

	public String get(int index) {
		return links.get(index);
	}

	public int size() {
		return links.size();
	}

	public String remove(int index) {
		return links.remove(index);
	}

	public boolean remove(String url) {
		return links.remove(url);
	}

	public void clear() {
		links.clear();
	}

	public boolean isEmpty() {
		return links.isEmpty();
	}

	public int indexOf(String url) {
		return links.indexOf(url);
	}

	@Override
	public String toString() {
		return links.toString();
	}
}
