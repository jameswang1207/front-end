package org.crawler.attitude.puller;

public class Executor {

}
