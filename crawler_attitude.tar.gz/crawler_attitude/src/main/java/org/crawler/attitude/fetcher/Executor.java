package org.crawler.attitude.fetcher;

import org.crawler.attitude.model.CrawlStructure;
import org.crawler.attitude.model.CrawlStructures;

public interface Executor {
	public void execute(CrawlStructure datum,CrawlStructures next) throws Exception;
}
