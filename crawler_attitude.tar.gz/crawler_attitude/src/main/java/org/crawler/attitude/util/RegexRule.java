package org.crawler.attitude.util;

public class RegexRule {

}
