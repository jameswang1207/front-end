package org.crawler.attitude.crawldb;

import org.crawler.attitude.model.CrawlStructure;

public abstract class DBManager implements Injector, Writer, DBLock {

	public abstract boolean isDBExists();

	public abstract void merge() throws Exception;

	@Override
	public void injector(CrawlStructure crawStructure) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void lock() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isLock() throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void unLock() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void initWriter() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void wrtieFetch(CrawlStructure fetchStructure) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void writeRedirect(CrawlStructure redirectStructure, String realUrl) throws Exception {
		// TODO Auto-generated method stub

	}
	

	@Override
	public void closeWriter() throws Exception {
		// TODO Auto-generated method stub

	}
	
	

}
