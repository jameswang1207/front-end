package org.crawler.attitude.plugin.mongo;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
/**
 * Mongo　对数据的增删改查
 * @author james
 *
 */
public class MongoDBUtils {
     public static void updateOrInsert(MongoCollection<Document> lock, Document doc){
    	 
     }
}
