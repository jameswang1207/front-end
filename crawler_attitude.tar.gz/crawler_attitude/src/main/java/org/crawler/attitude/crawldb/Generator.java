package org.crawler.attitude.crawldb;

import org.crawler.attitude.model.CrawlStructure;

/**
 * 任务生成器
 * @author james
 *
 */
public interface Generator {
    //设置某个任务执行的最大执行数
    public void setMaxExecuteCount(int maxExecuteCount);

    //获得执行器的数量
    public int getTotalGenerate();
    
    //获取下一个要抓取的数据结构
    public CrawlStructure next();
}