package org.crawler.attitude.model;

import java.io.Serializable;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 爬取任务的数据结构
 * @author JamesWang
 */
public class CrawlStructure implements Serializable{
    private static final Logger log = LoggerFactory.getLogger(CrawlStructure.class); 
    
	private static final long serialVersionUID = 1L;
	//status_db_unexecuted to do
    public final static int STATUS_DB_UNEXECUTED = 0;
    public final static int STATUS_DB_FAILED = 1;
    public final static int STATUS_DB_SUCCESS = 5;
    
    //爬虫获取的路径
    private String url = null;
    //任务执行时间
    private long executeTime =  System.currentTimeMillis();
    
    //数据数据库的状态
    private int status = STATUS_DB_UNEXECUTED;
    //任务执行的次数
    private int executeCount = 0;
    
    /**
     * 根据key去重可以通过getKey()方法获得CrawlStructure的key,如果key为null,getKey()方法会返回URL
     * 因此如果不设置key，爬虫会将URL当做key作为去重标准
     */
    private String key = null;
    
    /**
     * 为每个CrawlStructure添加附加信息metaData
     * 附加信息并不是为了持久化数据，而是为了能够更好地定制爬取任务
     * 在visit方法中，可以通过page.getMetaData()方法来访问CrawlStructure中的metaData
     */
    private HashMap<String, String> metaCollections = new HashMap<String, String>();
    
	public CrawlStructure(){
    	
    }
    
    public CrawlStructure(String url){
    	this.url = url;
    }
    
    public CrawlStructure(String url, String[] metas){
    	this(url);
    	if (metas.length % 2 != 0) {
    		try {
				throw new Exception("length of metas must be even");
			} catch (Exception e) {
				log.info("metas length is odd");
				e.printStackTrace();
			}
    	} else {
    		for(int i = 0; i < metas.length; i += 2){
    			meta(metas[i * 2], metas[i * 2 + 1]);
    		}
    	}
    }

    public HashMap<String, String> getMetaCollections() {
		return metaCollections;
	}

	public void setMetaCollections(HashMap<String, String> metaCollections) {
		this.metaCollections = metaCollections;
	}
	
    //设置计数器
    public int increaseExecuteCount(int count) {
        executeCount+=count;
        return executeCount;
    }
    
    //将meta的数据放入collections中
    public CrawlStructure meta(String key, String value){
    	this.metaCollections.put(key, value);
    	return this;
    }
    
    public String meta(String key){
    	return this.metaCollections.get(key);
    }
 
    public long getExecuteTime() {
		return executeTime;
	}

	public void setExecuteTime(long executeTime) {
		this.executeTime = executeTime;
	}

	public int getExecuteCount() {
		return executeCount;
	}

	public void setExecuteCount(int executeCount) {
		this.executeCount = executeCount;
	}

	//将meta的数据的放入容器中
    public CrawlStructure putMetaData(String key, String value){
    	return meta(key,value);
    }
    
    //获得meta从collections中
    public String getMetaData(String key){
    	return this.meta(key);
    }

    public String getUrl() {
        return url;
    }

    public CrawlStructure setUrl(String url) {
        this.url = url;
        return this;
    }
    
    public String getKey() {
    	return key;
    }

    public CrawlStructure setKey(String key) {
        this.key = key;
        return this;
    }

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
