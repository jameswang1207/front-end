package org.crawler.attitude.crawl;

import org.crawler.attitude.crawldb.DBManager;
import org.crawler.attitude.puller.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Crawler {
    private static final Logger log = LoggerFactory.getLogger(Crawler.class);
    
    //dbManager 任务管理器 
    private DBManager dbManager = null ;
    //executor 任务执行器
    private Executor executor = null;
    
    public Crawler(){
    	
    }
    
    public Crawler(DBManager dbManager, Executor executor){
        this.dbManager=dbManager;
        this.executor=executor;
    }
}
